# Global Student Portal - Dependency Graph in Neo4j

## Overview
This project sets up a Neo4j database to model component dependencies in the Global Student Portal.
It calculates **stability metrics** for each component using Cypher queries.

## Setup Instructions
1. Install [Docker](https://www.docker.com/).
2. Clone the repository:
   ```sh
   git clone <repo_url>
   cd <repo_name>
   ```
3. Start Neo4j using Docker:
   ```sh
   docker-compose up -d
   ```
4. Open [Neo4j Browser](http://localhost:7474/) and log in with `neo4j/test`.
5. Run the migration script:
   ```sh
   cat migration.cypher | docker exec -i neo4j cypher-shell -u neo4j -p test
   ```
6. Run the stability query:
   ```sh
   cat stability_query.cypher | docker exec -i neo4j cypher-shell -u neo4j -p test
   ```

## Stability Metrics
- **Fan-in**: Number of incoming dependencies.
- **Fan-out**: Number of outgoing dependencies.
- **Instability (I)**: `I = Fan-out / (Fan-in + Fan-out)`

## Example Output
| Component | FanIn | FanOut | Instability |
|-----------|-------|--------|-------------|
| API       | 1     | 1      | 0.50        |
| Auth      | 0     | 1      | 1.00        |
| Database  | 2     | 0      | 0.00        |
| Frontend  | 0     | 1      | 1.00        |

## License
MIT